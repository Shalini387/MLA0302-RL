import numpy as np
import random
import matplotlib.pyplot as plt


# =========================
# MODULE 1: GAME ENVIRONMENT
# =========================

class TicTacToe:

    def __init__(self):
        self.board = [0] * 9

    def reset(self):
        self.board = [0] * 9
        return tuple(self.board)

    def get_available_actions(self):
        return [i for i in range(9) if self.board[i] == 0]

    def make_move(self, action, player):
        if self.board[action] != 0:
            return False

        self.board[action] = player
        return True

    def check_winner(self, player):

        winning_positions = [
            (0, 1, 2),
            (3, 4, 5),
            (6, 7, 8),
            (0, 3, 6),
            (1, 4, 7),
            (2, 5, 8),
            (0, 4, 8),
            (2, 4, 6)
        ]

        for a, b, c in winning_positions:
            if self.board[a] == player and \
               self.board[b] == player and \
               self.board[c] == player:
                return True

        return False

    def is_draw(self):
        return len(self.get_available_actions()) == 0

    def display(self):

        symbols = {
            1: "X",
            -1: "O",
            0: " "
        }

        for i in range(9):
            print(symbols[self.board[i]], end="")

            if i % 3 != 2:
                print(" | ", end="")
            else:
                print()

                if i != 8:
                    print("---------")

    def get_state(self):
        return tuple(self.board)


# =========================
# MODULE 2: Q-LEARNING AGENT
# =========================

class QLearningAgent:

    def __init__(
        self,
        alpha=0.1,
        gamma=0.9,
        epsilon=1.0,
        epsilon_min=0.01,
        epsilon_decay=0.995
    ):

        self.alpha = alpha
        self.gamma = gamma

        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay

        self.q_table = {}

    def get_q_values(self, state):

        if state not in self.q_table:
            self.q_table[state] = np.zeros(9)

        return self.q_table[state]

    def choose_action(self, state, available_actions):

        # Exploration
        if random.random() < self.epsilon:
            return random.choice(available_actions)

        # Exploitation
        q_values = self.get_q_values(state)

        available_q_values = [
            q_values[action]
            for action in available_actions
        ]

        max_value = max(available_q_values)

        best_actions = [
            action
            for action in available_actions
            if q_values[action] == max_value
        ]

        return random.choice(best_actions)

    def update(
        self,
        state,
        action,
        reward,
        next_state,
        next_actions,
        done
    ):

        current_q = self.get_q_values(state)[action]

        if done:
            target = reward

        else:
            next_q_values = self.get_q_values(next_state)

            max_next_q = max(
                [next_q_values[a] for a in next_actions],
                default=0
            )

            target = reward + self.gamma * max_next_q

        new_q = current_q + self.alpha * (
            target - current_q
        )

        self.q_table[state][action] = new_q

    def decay_epsilon(self):

        self.epsilon = max(
            self.epsilon_min,
            self.epsilon * self.epsilon_decay
        )


# =========================
# RANDOM PLAYER
# =========================

def random_player(env):

    available_actions = env.get_available_actions()

    return random.choice(available_actions)


# =========================
# MODULE 3: TRAINING
# =========================

def train_agent(episodes=10000):

    env = TicTacToe()

    agent = QLearningAgent(
        alpha=0.1,
        gamma=0.9,
        epsilon=1.0,
        epsilon_min=0.01,
        epsilon_decay=0.995
    )

    rewards = []
    results = []

    for episode in range(episodes):

        state = env.reset()

        total_reward = 0
        done = False

        while not done:

            # Agent's turn
            available_actions = env.get_available_actions()

            action = agent.choose_action(
                state,
                available_actions
            )

            env.make_move(action, 1)

            # Agent wins
            if env.check_winner(1):

                reward = 1

                next_state = env.get_state()

                agent.update(
                    state,
                    action,
                    reward,
                    next_state,
                    [],
                    True
                )

                total_reward += reward
                results.append("Win")
                break

            # Draw
            if env.is_draw():

                reward = 0

                next_state = env.get_state()

                agent.update(
                    state,
                    action,
                    reward,
                    next_state,
                    [],
                    True
                )

                results.append("Draw")
                break

            # Random player's turn
            opponent_action = random_player(env)

            env.make_move(opponent_action, -1)

            # Agent loses
            if env.check_winner(-1):

                reward = -1

                next_state = env.get_state()

                agent.update(
                    state,
                    action,
                    reward,
                    next_state,
                    [],
                    True
                )

                total_reward += reward
                results.append("Loss")
                break

            # Draw after opponent move
            if env.is_draw():

                reward = 0

                next_state = env.get_state()

                agent.update(
                    state,
                    action,
                    reward,
                    next_state,
                    [],
                    True
                )

                results.append("Draw")
                break

            # Continue to next state
            next_state = env.get_state()

            next_actions = env.get_available_actions()

            agent.update(
                state,
                action,
                0,
                next_state,
                next_actions,
                False
            )

            state = next_state

        agent.decay_epsilon()

        rewards.append(total_reward)

        if (episode + 1) % 1000 == 0:

            recent_results = results[-1000:]

            wins = recent_results.count("Win")

            win_rate = wins / len(recent_results) * 100

            print(
                f"Episode: {episode + 1:5d} | "
                f"Win Rate: {win_rate:6.2f}% | "
                f"Epsilon: {agent.epsilon:.3f}"
            )

    return agent, rewards, results


# =========================
# MODULE 4: EVALUATION
# =========================

def evaluate_agent(agent, games=1000):

    env = TicTacToe()

    # Disable exploration
    agent.epsilon = 0

    wins = 0
    losses = 0
    draws = 0

    for _ in range(games):

        env.reset()

        while True:

            # Agent move
            state = env.get_state()

            available_actions = env.get_available_actions()

            action = agent.choose_action(
                state,
                available_actions
            )

            env.make_move(action, 1)

            if env.check_winner(1):

                wins += 1
                break

            if env.is_draw():

                draws += 1
                break

            # Random opponent move
            opponent_action = random_player(env)

            env.make_move(opponent_action, -1)

            if env.check_winner(-1):

                losses += 1
                break

            if env.is_draw():

                draws += 1
                break

    win_rate = wins / games * 100

    print("\n===== EVALUATION RESULTS =====")

    print("Total Games :", games)
    print("Wins        :", wins)
    print("Losses      :", losses)
    print("Draws       :", draws)
    print(f"Win Rate    : {win_rate:.2f}%")

    return wins, losses, draws


# =========================
# VISUALIZATION
# =========================

def plot_results(rewards, results):

    # Moving average reward
    window = 500

    moving_average = np.convolve(
        rewards,
        np.ones(window) / window,
        mode="valid"
    )

    plt.figure(figsize=(10, 5))

    plt.plot(moving_average)

    plt.title("Training Performance - Average Reward")
    plt.xlabel("Episode")
    plt.ylabel("Average Reward")

    plt.grid()

    plt.show()

    # Win rate over training
    win_rates = []

    for i in range(1000, len(results) + 1, 1000):

        recent = results[i - 1000:i]

        wins = recent.count("Win")

        win_rate = wins / 1000 * 100

        win_rates.append(win_rate)

    plt.figure(figsize=(10, 5))

    plt.plot(
        range(1000, len(results) + 1, 1000),
        win_rates,
        marker="o"
    )

    plt.title("Training Win Rate")
    plt.xlabel("Episode")
    plt.ylabel("Win Rate (%)")

    plt.grid()

    plt.show()


# =========================
# MAIN PROGRAM
# =========================

if __name__ == "__main__":

    print("Starting Q-Learning Tic-Tac-Toe Training...")

    agent, rewards, results = train_agent(
        episodes=10000
    )

    print("\nTraining completed!")

    evaluate_agent(
        agent,
        games=1000
    )

    plot_results(
        rewards,
        results
    )