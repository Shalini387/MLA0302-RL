let board = [
    0, 0, 0,
    0, 0, 0,
    0, 0, 0
];

let gameOver = false;


// =====================================
// PLAYER MOVE
// =====================================

function play(index) {

    if (gameOver) {
        return;
    }

    if (board[index] !== 0) {
        return;
    }

    // Player = O
    board[index] = -1;

    updateBoard();

    if (checkWinner(-1)) {

        document.getElementById("status").innerText =
            "🎉 You Win!";

        gameOver = true;

        return;
    }

    if (!board.includes(0)) {

        document.getElementById("status").innerText =
            "🤝 Draw!";

        gameOver = true;

        return;
    }

    document.getElementById("status").innerText =
        "🤖 AI is thinking...";

    getAIMove();
}


// =====================================
// GET AI MOVE
// =====================================

function getAIMove() {

    fetch("/api/ai-move", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            board: board
        })

    })

    .then(response => response.json())

    .then(data => {

        // Show Q-values BEFORE updating board
        displayQValues(
            data.q_values,
            data.available_actions,
            data.move
        );

        board = data.board;

        updateBoard();

        if (data.result === "AI Wins") {

            document.getElementById("status").innerText =
                "🤖 AI Wins!";

            gameOver = true;

        }

        else if (data.result === "Draw") {

            document.getElementById("status").innerText =
                "🤝 Draw!";

            gameOver = true;

        }

        else {

            document.getElementById("status").innerText =
                "Your Turn";

        }

    })

    .catch(error => {

        console.error(error);

        document.getElementById("status").innerText =
            "Connection Error";

    });
}


// =====================================
// DISPLAY Q VALUES
// =====================================

function displayQValues(
    qValues,
    availableActions,
    selectedAction
) {

    const container =
        document.getElementById("q-values");

    if (!container) {
        return;
    }

    container.innerHTML = "";

    for (let i = 0; i < 9; i++) {

        const row =
            document.createElement("div");

        row.className = "q-value-row";

        const cell =
            document.createElement("span");

        cell.innerText =
            "Cell " + (i + 1);

        const value =
            document.createElement("span");

        if (availableActions.includes(i)) {

            value.innerText =
                qValues[i].toFixed(3);

        } else {

            value.innerText =
                "Occupied";

        }

        if (i === selectedAction) {

            row.classList.add("selected");

            value.innerText +=
                "  ← Selected";

        }

        row.appendChild(cell);

        row.appendChild(value);

        container.appendChild(row);
    }
}


// =====================================
// UPDATE BOARD
// =====================================

function updateBoard() {

    const buttons =
        document.querySelectorAll("#board button");

    for (let i = 0; i < 9; i++) {

        if (board[i] === 1) {

            buttons[i].innerText = "X";

        }

        else if (board[i] === -1) {

            buttons[i].innerText = "O";

        }

        else {

            buttons[i].innerText = "";

        }

    }
}


// =====================================
// CHECK WINNER
// =====================================

function checkWinner(player) {

    const winningPositions = [

        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],

        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],

        [0, 4, 8],
        [2, 4, 6]

    ];

    for (const position of winningPositions) {

        const [a, b, c] = position;

        if (

            board[a] === player &&
            board[b] === player &&
            board[c] === player

        ) {

            return true;

        }

    }

    return false;
}