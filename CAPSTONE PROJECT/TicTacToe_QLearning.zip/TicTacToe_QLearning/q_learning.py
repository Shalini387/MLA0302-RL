import numpy as np
import random


class TicTacToe:

    def __init__(self):
        self.board = [0] * 9

    def reset(self):
        self.board = [0] * 9
        return tuple(self.board)

    def get_available_actions(self):
        return [i for i in range(9) if self.board[i] == 0]

    def make_move(self, action, player):

        if self.board[action] != 0:
            return False

        self.board[action] = player
        return True

    def check_winner(self, player):

        winning_positions = [
            (0, 1, 2),
            (3, 4, 5),
            (6, 7, 8),
            (0, 3, 6),
            (1, 4, 7),
            (2, 5, 8),
            (0, 4, 8),
            (2, 4, 6)
        ]

        for a, b, c in winning_positions:

            if (
                self.board[a] == player
                and self.board[b] == player
                and self.board[c] == player
            ):
                return True

        return False

    def is_draw(self):
        return len(self.get_available_actions()) == 0

    def get_state(self):
        return tuple(self.board)


class QLearningAgent:

    def __init__(
        self,
        alpha=0.1,
        gamma=0.9,
        epsilon=1.0,
        epsilon_min=0.01,
        epsilon_decay=0.999
    ):

        self.alpha = alpha
        self.gamma = gamma

        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay

        self.q_table = {}

    def get_q_values(self, state):

        if state not in self.q_table:

            self.q_table[state] = np.zeros(9)

        return self.q_table[state]

    def choose_action(self, state, available_actions):

        # Exploration
        if random.random() < self.epsilon:

            return random.choice(available_actions)

        # Exploitation
        q_values = self.get_q_values(state)

        best_value = max(
            q_values[action]
            for action in available_actions
        )

        best_actions = [
            action
            for action in available_actions
            if q_values[action] == best_value
        ]

        return random.choice(best_actions)

    def update(
        self,
        state,
        action,
        reward,
        next_state,
        next_actions,
        done
    ):

        current_q = self.get_q_values(state)[action]

        if done:

            target = reward

        else:

            next_q_values = self.get_q_values(next_state)

            if next_actions:

                max_next_q = max(
                    next_q_values[a]
                    for a in next_actions
                )

            else:

                max_next_q = 0

            target = (
                reward
                + self.gamma * max_next_q
            )

        self.q_table[state][action] = (
            current_q
            + self.alpha * (target - current_q)
        )

    def decay_epsilon(self):

        self.epsilon = max(
            self.epsilon_min,
            self.epsilon * self.epsilon_decay
        )


def random_player(env):

    actions = env.get_available_actions()

    return random.choice(actions)

def tactical_move(env):

    board = env.board

    winning_positions = [
        (0, 1, 2),
        (3, 4, 5),
        (6, 7, 8),
        (0, 3, 6),
        (1, 4, 7),
        (2, 5, 8),
        (0, 4, 8),
        (2, 4, 6)
    ]

    # =================================
    # 1. AI CAN WIN
    # =================================

    for a, b, c in winning_positions:

        line = [board[a], board[b], board[c]]

        if line.count(1) == 2 and line.count(0) == 1:

            if board[a] == 0:
                return a

            if board[b] == 0:
                return b

            if board[c] == 0:
                return c

    # =================================
    # 2. BLOCK OPPONENT
    # =================================

    for a, b, c in winning_positions:

        line = [board[a], board[b], board[c]]

        if line.count(-1) == 2 and line.count(0) == 1:

            if board[a] == 0:
                return a

            if board[b] == 0:
                return b

            if board[c] == 0:
                return c

    # =================================
    # 3. NO TACTICAL MOVE
    # =================================

    return None
# ==========================================
# TRAINING
# ==========================================

def train_agent(episodes=10000):

    env = TicTacToe()

    agent = QLearningAgent(
        alpha=0.1,
        gamma=0.9,
        epsilon=1.0,
        epsilon_min=0.01,
        epsilon_decay=0.999
    )

    rewards = []
    results = []

    for episode in range(episodes):

        env.reset()

        total_reward = 0

        while True:

            # ==============================
            # AI TURN
            # ==============================

            state = env.get_state()

            available_actions = env.get_available_actions()

            # Q-Learning chooses the action
            action = agent.choose_action(
                state,
                available_actions
            )

            env.make_move(action, 1)

            # AI wins
            if env.check_winner(1):

                agent.update(
                    state,
                    action,
                    1,
                    env.get_state(),
                    [],
                    True
                )

                total_reward = 1
                results.append("Win")

                break

            # Draw
            if env.is_draw():

                agent.update(
                    state,
                    action,
                    0,
                    env.get_state(),
                    [],
                    True
                )

                results.append("Draw")

                break


            # ==============================
            # RANDOM OPPONENT
            # ==============================

            opponent_action = random_player(env)

            env.make_move(
                opponent_action,
                -1
            )

            # Opponent wins
            if env.check_winner(-1):

                agent.update(
                    state,
                    action,
                    -1,
                    env.get_state(),
                    [],
                    True
                )

                total_reward = -1
                results.append("Loss")

                break

            # Draw
            if env.is_draw():

                agent.update(
                    state,
                    action,
                    0,
                    env.get_state(),
                    [],
                    True
                )

                results.append("Draw")

                break


            # ==============================
            # NEXT STATE
            # ==============================

            next_state = env.get_state()

            next_actions = env.get_available_actions()

            agent.update(
                state,
                action,
                0,
                next_state,
                next_actions,
                False
            )

        agent.decay_epsilon()

        rewards.append(total_reward)

        if (episode + 1) % 1000 == 0:

            recent = results[-1000:]

            print(
                f"Episode {episode + 1}: "
                f"Wins={recent.count('Win')}, "
                f"Draws={recent.count('Draw')}, "
                f"Losses={recent.count('Loss')}, "
                f"Epsilon={agent.epsilon:.3f}, "
                f"Q-States={len(agent.q_table)}"
            )

    return agent, rewards, results

# ==========================================
# EVALUATION
# ==========================================

def evaluate_agent(agent, games=1000):

    env = TicTacToe()

    # No exploration during testing
    agent.epsilon = 0

    wins = 0
    losses = 0
    draws = 0

    for _ in range(games):

        env.reset()

        while True:

            # AI move
            state = env.get_state()

            available_actions = env.get_available_actions()

            action = agent.choose_action(
                state,
                available_actions
            )

            env.make_move(action, 1)

            if env.check_winner(1):

                wins += 1
                break

            if env.is_draw():

                draws += 1
                break

            # Random player move
            opponent_action = random_player(env)

            env.make_move(
                opponent_action,
                -1
            )

            if env.check_winner(-1):

                losses += 1
                break

            if env.is_draw():

                draws += 1
                break

    return wins, losses, draws