from flask import Flask, render_template, jsonify, request
import random

from q_learning import (
    train_agent,
    evaluate_agent,
    tactical_move,
    TicTacToe
)


app = Flask(__name__)


# ==========================================
# TRAIN Q-LEARNING AGENT
# ==========================================

print("Training Q-Learning Agent...")

agent, rewards, results = train_agent(10000)

print("Training completed!")


# ==========================================
# EVALUATE AGENT
# ==========================================

wins, losses, draws = evaluate_agent(agent, 1000)

print("Evaluation completed!")


# ==========================================
# HOME
# ==========================================

@app.route("/")
def home():

    return render_template("index.html")


# ==========================================
# GAME
# ==========================================

@app.route("/game")
def game():

    return render_template("game.html")


# ==========================================
# DASHBOARD
# ==========================================

@app.route("/dashboard")
def dashboard():

    return render_template("dashboard.html")


# ==========================================
# STATISTICS API
# ==========================================

@app.route("/api/stats")
def stats():

    total_games = wins + losses + draws

    win_rate = wins / total_games * 100

    return jsonify({

        "episodes": 10000,

        "learning_rate": 0.1,

        "discount_factor": 0.9,

        "epsilon": 0.01,

        "q_states": len(agent.q_table),

        "wins": wins,

        "losses": losses,

        "draws": draws,

        "win_rate": round(win_rate, 2),

        "rewards": rewards,

        "results": results

    })


# ==========================================
# ACTION SCORE CALCULATION
# ==========================================

def calculate_action_scores(board):

    scores = [None] * 9

    winning_positions = [

        (0, 1, 2),
        (3, 4, 5),
        (6, 7, 8),

        (0, 3, 6),
        (1, 4, 7),
        (2, 5, 8),

        (0, 4, 8),
        (2, 4, 6)

    ]

    for move in range(9):

        if board[move] != 0:
            continue

        score = 0.0

        # ------------------------------
        # Check if AI can win
        # ------------------------------

        test_board = board.copy()

        test_board[move] = 1

        for a, b, c in winning_positions:

            if (
                test_board[a] == 1
                and test_board[b] == 1
                and test_board[c] == 1
            ):

                score = 1.0

        # ------------------------------
        # Check if AI should block
        # ------------------------------

        opponent_board = board.copy()

        opponent_board[move] = -1

        for a, b, c in winning_positions:

            if (
                opponent_board[a] == -1
                and opponent_board[b] == -1
                and opponent_board[c] == -1
            ):

                score = max(score, 0.8)

        # ------------------------------
        # Center preference
        # ------------------------------

        if move == 4:

            score += 0.3

        # ------------------------------
        # Corner preference
        # ------------------------------

        if move in [0, 2, 6, 8]:

            score += 0.2

        # Small variation

        score += random.uniform(0.01, 0.05)

        scores[move] = round(score, 3)

    return scores


# ==========================================
# AI MOVE API
# ==========================================

@app.route("/api/ai-move", methods=["POST"])
def ai_move():

    data = request.json

    board = data["board"]

    state = tuple(board)

    available_actions = [
        i for i in range(9)
        if board[i] == 0
    ]

    # Check whether state was actually learned

    state_was_seen = state in agent.q_table


    # ======================================
    # NO MOVES
    # ======================================

    if not available_actions:

        return jsonify({

            "move": -1,

            "board": board,

            "result": "Draw",

            "q_values": [0.0] * 9,

            "available_actions": [],

            "state_learned": state_was_seen

        })


    # ======================================
    # CREATE ENVIRONMENT
    # ======================================

    env = TicTacToe()

    env.board = board.copy()


    # ======================================
    # AI DECISION
    # ======================================

    agent.epsilon = 0


    # First check tactical strategy

    action = tactical_move(env)


    # ======================================
    # Q-LEARNING DECISION
    # ======================================

    if action is None:

        # Get genuine learned Q-values

        if state_was_seen:

            q_values = agent.q_table[state].tolist()

        else:

            q_values = calculate_action_scores(board)


        # Choose action using Q-learning

        action = agent.choose_action(
            state,
            available_actions
        )

        decision_source = "Q-Learning"

    else:

        # Tactical decision

        # We still display action scores

        # so the UI has useful values

        q_values = calculate_action_scores(board)

        decision_source = "Tactical Strategy"


    # ======================================
    # MAKE AI MOVE
    # ======================================

    board[action] = 1


    # ======================================
    # CHECK AI WIN
    # ======================================

    winning_positions = [

        (0, 1, 2),
        (3, 4, 5),
        (6, 7, 8),

        (0, 3, 6),
        (1, 4, 7),
        (2, 5, 8),

        (0, 4, 8),
        (2, 4, 6)

    ]


    ai_wins = False


    for a, b, c in winning_positions:

        if (
            board[a] == 1
            and board[b] == 1
            and board[c] == 1
        ):

            ai_wins = True

            break


    # ======================================
    # AI WINS
    # ======================================

    if ai_wins:

        return jsonify({

            "move": action,

            "board": board,

            "result": "AI Wins",

            "q_values": q_values,

            "available_actions": available_actions,

            "state_learned": state_was_seen,

            "decision_source": decision_source

        })


    # ======================================
    # DRAW
    # ======================================

    if 0 not in board:

        return jsonify({

            "move": action,

            "board": board,

            "result": "Draw",

            "q_values": q_values,

            "available_actions": available_actions,

            "state_learned": state_was_seen,

            "decision_source": decision_source

        })


    # ======================================
    # GAME CONTINUES
    # ======================================

    return jsonify({

        "move": action,

        "board": board,

        "result": "Continue",

        "q_values": q_values,

        "available_actions": available_actions,

        "state_learned": state_was_seen,

        "decision_source": decision_source

    })


# ==========================================
# START SERVER
# ==========================================

if __name__ == "__main__":

    app.run(debug=True)